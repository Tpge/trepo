local cube = dofile("include/cube.lua")

return function(page, offset)
    cube(page, offset, true)
end
